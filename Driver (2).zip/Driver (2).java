public class Driver {
    public static void main(String[] args) {

        System.out.println("\n\nRecursion Demo.");
       // countDown(10);
       // System.out.println(sumOf(3));
        int [] array1 = {1,2,3};
     //   displayArray(array1,0,6);
        System.out.println();
        displayArray2(array1,0,2);
    }  // end main

    public static void countDown(int integer)
    {
        System.out.println(integer);
        if (integer > 1)
            countDown(integer - 1);
    } // end countDown

    public static int sumOf(int n)
    {
        int sum;
        if (n == 1)
            sum = 1;                // Base case
        else
            sum = sumOf(n - 1) + n; // Recursive call

        return sum;
    } // end sumOf

    public static void displayArray(int array[], int first, int last)
    {
        System.out.print(array[first] + " ");
        if (first < last)
            displayArray(array, first + 1, last);
    } // end displayArray

    public static void displayArray2(int array[], int first, int last)
    {
        if (first <= last)
        {
            System.out.print(array[last] + " ");
            displayArray(array, first, last - 1);
           // System.out.print(array[last] + " ");
        } // end if
    } // end


}